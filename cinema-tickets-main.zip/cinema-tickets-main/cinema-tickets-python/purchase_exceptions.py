
class InvalidPurchaseException(Exception):

    pass
