
from ticket_service import TicketService


if __name__ == '__main__':

    ticket_service = TicketService()

    ticket_service.purchase_tickets()
