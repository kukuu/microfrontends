
from purchase_exceptions import InvalidPurchaseException


class TicketService:

    """

      purchase_tickets should be the only public method

    """

    def purchase_tickets(account_id=None, ticket_type_requests=[]):

        raise InvalidPurchaseException
